import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UploadDataComponent } from './upload-data/upload-data.component';
import { TreeComponent } from './tree/tree/tree.component';
import { ExtractTextComponent } from './extract-text/extract-text.component';
import { LandingPageComponent } from './landing-page/landing-page.component';

const routes: Routes = [
  {path: '', redirectTo: '/landing-page', pathMatch: 'full'},
  {
    path:'landing-page',component:LandingPageComponent,
    children:[
      {path:'hierarchy',component:TreeComponent},
      {path:'uploadData',component:UploadDataComponent},
      {path:'extract-text',component:ExtractTextComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
