import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http : HttpClient) { }

  getLiveDashBoard(){
    return this.http.get('./assets/liveDashboardData.json');
  }

  getEmployeeData(){
    return this.http.get("http://127.0.0.1:8000/employee/employeeList/");
  }

  getProcessingSupplyFile(){
    return this.http.get("http://127.0.0.1:8000/employee/supplyProcessing/");
  }

  getDemand(){
    return this.http.get("http://127.0.0.1:8000/supply/DemandOrderlist/");
  }

  getSupply(){
    return this.http.get("http://127.0.0.1:8000/supply/Supplylist/");
  }

  getRule(){
    return this.http.get("http://127.0.0.1:8000/supply/Rulelist/");
  }

  getOutput(){
    return this.http.get("http://127.0.0.1:8000/supply/Outputlist/");
  }
}
