import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {

  @HostListener('click',['$event']) onClick(event) {
    if(event.target.id == 'sideNav'){
      this.sideNavFlag = true;
    }
    else{
      this.sideNavFlag = false;
    }
  }

  constructor(private router : Router) { }

  EmpHierarchy:boolean = false;
  SupplyManagement:boolean = false;
  TextExtract:boolean = false;
  sideNavFlag:boolean = false;

  ngOnInit() {
  }

  clickEmpHierarchy(){
    this.router.navigate(['/landing-page/hierarchy']);
    this.EmpHierarchy = true;
    this.SupplyManagement = false;
    this.TextExtract = false;
  }

  clickSupplyManagement(){
    this.router.navigate(['/landing-page/uploadData']);
    this.EmpHierarchy = false;
    this.SupplyManagement = true;
    this.TextExtract = false;
  }

  clickTextExtract(){
    this.router.navigate(['/landing-page/extract-text']);
    this.EmpHierarchy = false;
    this.SupplyManagement = false;
    this.TextExtract = true;
  }

  enableSideNav(){
    this.sideNavFlag = true;
  }

}
