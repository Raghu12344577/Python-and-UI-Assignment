import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-extract-text',
  templateUrl: './extract-text.component.html',
  styleUrls: ['./extract-text.component.css']
})
export class ExtractTextComponent implements OnInit {

  constructor(private http:HttpClient) { }

  file: File

  extractedTextName;
  extractedTextFlag = false;
  imageUploadFlag = false;
  extractProgressValue = 0;

  ngOnInit() {
  }

  processFile(event){
    this.file = event.target.files[0];
    this.imageUploadFlag = true;
    this.extractedTextFlag = false;
  }

  onUpload(){
    console.log("onUpload extarct text");
    this.extractProgressValue = 10;
    const formData = new FormData(); 
    formData.append("file", this.file, this.file.name);
    this.extractProgressValue = 30;
    this.http.post("http://127.0.0.1:8000/employee/extractTextFromImage/",formData).subscribe(data =>{
      this.extractProgressValue = 50;
      this.extractedTextName = data;
      this.imageUploadFlag = false;
      this.extractedTextFlag = true;
      this.extractProgressValue = 100;
    })
  }

}
