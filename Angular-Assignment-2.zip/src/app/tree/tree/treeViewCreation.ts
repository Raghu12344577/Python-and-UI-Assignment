export class employeeHierarchy{
    private data;
    private parent;
    private children;
    private root;

    constructor(){
    }

    Node(data) {
        this.data = data;
        this.parent = null;
        this.children = [];
    }
}