import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {NODES} from '../mock-nodes';
import {employeeHierarchy} from '../tree/treeViewCreation';
import {DashboardService} from '../../service/dashboard.service';

@Component({
  selector: 'app-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.css']
})
export class TreeComponent implements OnInit {

  constructor(private router : Router,private dashboardService : DashboardService) { }
  treeData:any ;
  treeDataAcc = true;
  EmployeeHierarchy = new employeeHierarchy();
  defaultColDef = {
    resizable: true,
    enableCellChangeFlash: true
  };
  groupDefaultExpanded = -1;
  getDataPath = function(data) {
    return data.orgHierarchy;
  };
  
  columnDefs = [
    {headerName: 'In Time', field: 'InTime', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Out Time', field: 'OutTime', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Average Working Hours', field: 'HoursDiff', sortable: false,enableCellChangeFlash: true, cellStyle: this.cellStyling},
    {headerName: 'Attendance', field: 'Attendance', sortable: false,enableCellChangeFlash: true}
  ];

  cellStyling(params:any){   
    if (params.data.HoursDiff > 4) {
      return {'background-color': 'lightgreen',color:'#fff'};
     } 
     else {
      return {'background-color': 'lightpink',color:'#fff'};
    }
 
 }

  rowStyle = { background: '#fff' };
  
  ngOnInit() {
    this.dashboardService.getEmployeeData().subscribe(data =>{
      this.treeData = data;
      this.passingData(this.treeData)
    })
  }

  passingData(treeData){
    console.log("treeData",this.treeData);
    var dummyTreeData = treeData.map(item =>{
      if(item.orgHierarchy.includes(',')){
        item.orgHierarchy = item.orgHierarchy.split(",")
      }
      else{
        item.orgHierarchy = [item.orgHierarchy];
      }
      item.HoursDiff = this.getTimeDiff(item.InTime,item.OutTime);
      item.Attendance = item.HoursDiff > 4 ? 'Present' : 'Absent'
      return item;
    })
    this.treeData = dummyTreeData;
  }

  getTimeDiff(date1,date2){
    var date1Hour:any;
    var date2Hour:any;
    date1Hour = new Date(date1).getHours();
    date2Hour = new Date(date2).getHours();
    var dateDiff = date2Hour - date1Hour;
    return dateDiff;
  }
}
