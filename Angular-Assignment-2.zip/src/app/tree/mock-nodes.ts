export const NODES = 
    [
        {
            orgHierarchy: ["Vivek Goel"],
            name: 'Vivek Goel',
            InTime : '12/06/2021 10:30:00',
            OutTime : '12/06/2021 20:30:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra"],
            name : 'Narayan Mahapatra',
            InTime : '12/06/2021 10:00:00',
            OutTime : '12/06/2021 20:20:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra","Kaushik Das"],
            name : 'Kaushik Das',
            InTime : '12/06/2021 9:15:00',
            OutTime : '12/06/2021 20:00:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra","Kaushik Das","Madhusmita Dash"],
            name : 'Madhusmita Dash',
            InTime : '12/06/2021 11:30:00',
            OutTime : '12/06/2021 21:00:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra","Kaushik Das","Anila Ramachandran"],
            name : 'Anila Ramachandran',
            InTime : '12/06/2021 11:00:00',
            OutTime : '12/06/2021 19:30:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra","Kaushik Das","Anila Ramachandran","Raghunathan S"],
            name : 'Raghunathan S',
            InTime : '12/06/2021 14:30:00',
            OutTime : '12/06/2021 18:30:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra","Kaushik Das","Anila Ramachandran","Nilesh Sinha"],
            name : 'Nilesh Sinha',
            InTime : '12/06/2021 11:30:00',
            OutTime : '12/06/2021 20:30:00'
        },
        {
            orgHierarchy: ["Vivek Goel","Narayan Mahapatra","Kaushik Das","Anila Ramachandran","Abhijit Chakrabarty"],
            name : 'Abhijit Chakrabarty',
            InTime : '12/06/2021 10:30:00',
            OutTime : '12/06/2021 17:30:00'
        }
    ]