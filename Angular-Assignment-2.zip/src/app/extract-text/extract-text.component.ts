import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-extract-text',
  templateUrl: './extract-text.component.html',
  styleUrls: ['./extract-text.component.css']
})
export class ExtractTextComponent implements OnInit {

  constructor(private http:HttpClient) { }

  file: File

  extractedTextName;
  extractedTextFlag = false;
  imageUploadFlag = false;

  ngOnInit() {
  }

  processFile(event){
    this.file = event.target.files[0];
    this.imageUploadFlag = true;
    this.extractedTextFlag = false;
  }

  onUpload(){
    console.log("onUpload extarct text")
    const formData = new FormData(); 
    formData.append("file", this.file, this.file.name);
    this.http.post("http://127.0.0.1:8000/employee/extractTextFromImage/",formData).subscribe(data =>{
      this.extractedTextName = data;
      this.imageUploadFlag = false;
      this.extractedTextFlag = true;
    })
  }

}
