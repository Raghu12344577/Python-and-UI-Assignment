import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DashboardService } from '../service/dashboard.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-upload-data',
  templateUrl: './upload-data.component.html',
  styleUrls: ['./upload-data.component.css']
})
export class UploadDataComponent implements OnInit {

  demandfile:File;
  supplyfile:File;
  rulefile:File;
  demandorderFlag = false;
  supplyFlag = false;
  sourcingFlag = false;
  fileUploadStatus ;
  fileUploadStatusFlag = false;
  fileprocessingFlag = false;
  demandDataArr = [];
  supplyDataArr = [];
  rulesDataArr = [];
  outputDataArr = [];
  outputTabEnableAfterProcessFlag = false;
  outputTabFlag = false;
  threeTabFlag = false;

  defaultColDef = {
    resizable: true,
    enableCellChangeFlash: true
  };
  columnDefsDemand = [
    {headerName: 'Customer', field: 'customer', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Product', field: 'product', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Date', field: 'date', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Quantity', field: 'quantity', sortable: false,enableCellChangeFlash: true}
  ]

  columnDefsSupply = [
    {headerName: 'Site', field: 'site', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Product', field: 'product', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Date', field: 'date', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Quantity', field: 'quantity', sortable: false,enableCellChangeFlash: true}
  ]

  columnDefsRule = [
    {headerName: 'Site', field: 'site', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Customer', field: 'customer', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Product', field: 'product', sortable: false,enableCellChangeFlash: true}
  ]

  columnDefsOutput = [
    {headerName: 'Site', field: 'site', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Customer', field: 'customer', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Product', field: 'product', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-01', field: '2019-07-01', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-02', field: '2019-07-02', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-03', field: '2019-07-03', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-04', field: '2019-07-04', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-05', field: '2019-07-05', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-06', field: '2019-07-06', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-07', field: '2019-07-07', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-08', field: '2019-07-08', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-09', field: '2019-07-09', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-10', field: '2019-07-10', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-11', field: '2019-07-11', sortable: false,enableCellChangeFlash: true},
    {headerName: '2019-07-12', field: '2019-07-12', sortable: false,enableCellChangeFlash: true}
  ]

  constructor(private http : HttpClient,private dashboardService : DashboardService) { }

  ngOnInit() {
    this.getDemandData();
  }

  browseFileDemandOrder(event){
    this.fileUploadStatusFlag = false;
    this.fileUploadStatus = '';
    this.demandfile = event.target.files[0];
    this.demandorderFlag = true;
    const formData = new FormData();
    formData.append("file",this.demandfile,this.demandfile.name);
    this.http.post("http://127.0.0.1:8000/employee/upload/",formData).subscribe(data =>{
      this.fileUploadStatus = data;
      this.fileUploadStatusFlag = true;
      this.TabSectionVisibleCheck()
    })
  }

  browseFileSourcing(event){
    this.fileUploadStatusFlag = false;
    this.fileUploadStatus = '';
    this.rulefile = event.target.files[0];
    this.sourcingFlag = true;
    const formData = new FormData();
    formData.append("file",this.rulefile,this.rulefile.name);
    this.http.post("http://127.0.0.1:8000/employee/upload/",formData).subscribe(data =>{
      this.fileUploadStatus = data;
      this.fileUploadStatusFlag = true;
      this.TabSectionVisibleCheck()
    })
  }

  browseFileSupply(event){
    this.fileUploadStatusFlag = false;
    this.fileUploadStatus = '';
    this.supplyfile = event.target.files[0];
    this.supplyFlag = true;
    const formData = new FormData();
    formData.append("file",this.supplyfile,this.supplyfile.name);
    this.http.post("http://127.0.0.1:8000/employee/upload/",formData).subscribe(data =>{
      this.fileUploadStatus = data;
      this.fileUploadStatusFlag = true;
      this.TabSectionVisibleCheck();
    })
  }

  TabSectionVisibleCheck(){
    if(this.demandorderFlag && this.supplyFlag && this.sourcingFlag){
      this.fileprocessingFlag = true;
      this.threeTabFlag = true;
    }
    else{
      this.fileprocessingFlag = true;
      this.threeTabFlag = true;
    }
  }

  uploadFile(){
    const formData = new FormData();
    var fileCategory;
    if(this.demandorderFlag){
      fileCategory = 'Demand Order';
    }
    else if(this.sourcingFlag){
      fileCategory = 'Sourcing Rule';
    }
    else if(this.supplyFlag){
      fileCategory = 'Supply';
    }
    formData.append("file",this.demandfile,this.demandfile.name);
    formData.append("supplyfile",this.supplyfile,this.supplyfile.name);
    formData.append("rulefile",this.rulefile,this.rulefile.name);
    formData.append("fileCategory",fileCategory);
    this.http.post("http://127.0.0.1:8000/employee/upload/",formData).subscribe(data =>{
      this.fileUploadStatus = "Files has been uploaded successfully";
      this.demandorderFlag = false;
      this.sourcingFlag = false;
      this.supplyFlag = false;
      this.threeTabFlag = true;
      this.fileprocessingFlag = true;
    })
  }

  ProcessingSupplyManagement(){
    this.fileprocessingFlag = false;
    this.outputTabEnableAfterProcessFlag = true;
    this.dashboardService.getProcessingSupplyFile().subscribe(data =>{
      
    })
  }

  downloadFile(data) {
    const data1: Blob = new Blob([data], { type: "text/csv;charset=utf-8" });
    saveAs(data1, 'allocation_output.csv');
  }

  onTabChange(event){
    this.outputTabFlag = false;
    console.log("onTabChange",event);
    if(event == 0){
      this.getDemandData();
    }
    else if(event == 1){
      this.getSupplyData();
    }
    else if(event == 2){
      this.getRuleData();
    }
    else if(event == 3){
      if(this.outputTabEnableAfterProcessFlag){
        this.outputTabFlag = true;
      }
      this.getOutputData();
    }
  }

  getDemandData(){
    this.dashboardService.getDemand().subscribe((data:any) =>{
      this.demandDataArr = data;
    })
  }

  getSupplyData(){
    this.dashboardService.getSupply().subscribe((data:any) =>{
      this.supplyDataArr = data;
    })
  }

  getRuleData(){
    this.dashboardService.getRule().subscribe((data:any) =>{
      this.rulesDataArr = data;
    })
  }

  getOutputData(){
    this.dashboardService.getOutput().subscribe((data:any) =>{
      this.outputDataArr = data;
      // this.downloadFile(this.outputDataArr);
    })
  }
}
