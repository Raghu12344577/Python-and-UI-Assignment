import { Component, OnInit } from '@angular/core';
import { DashboardService } from './service/dashboard.service';
import 'ag-grid-enterprise';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'hierarchical-dashboard';
  groupDisplayType;
  groupDefaultExpanded = -1;
  updateBtnFlag : boolean = false;

  employeeId = '';
  employeeInTime = '';
  employeeOuttime = '';

  constructor(private dashboardService : DashboardService){
    this.groupDisplayType = 'singleColumn';
  }

  defaultColDef = {
    enableCellChangeFlash: true
  };

  columnDefs = [
    {headerName: 'Employee Id', field: 'id', sortable: true,enableCellChangeFlash: true},
    {headerName: 'Employee Name', field: 'name', sortable: true,enableCellChangeFlash: true},
    {headerName: 'Reporting To', field: 'reportingTo', sortable: true,rowGroup: true,hide: true,enableCellChangeFlash: true},
    {headerName: 'In Time', field: 'InTime', sortable: false,enableCellChangeFlash: true},
    {headerName: 'Out Time', field: 'OutTime', sortable: false,enableCellChangeFlash: true}
  ];

  rowData : any;

  rowStyle = { background: '#fff' };

  ngOnInit(){
    this.dashboardService.getLiveDashBoard().subscribe(data =>{
      console.log("getLiveDashBoard",data);
      this.rowData = data;
      this.rowData.map(item =>{
        item.timeDiff =  Math.floor(Number(item.OutTime - item.InTime));
        return item;
      })
    })
  }

  enterEmployeeId(event){
    this.employeeId = event.target.value;
    this.enableUpdateBtn();
  }

  enterEmployeeIntime(event){
    this.employeeInTime = event.target.value;
    this.enableUpdateBtn();
  }

  enterEmployeeOuttime(event){
    this.employeeOuttime = event.target.value;
    this.enableUpdateBtn();
  }

  clickedUpdateBtn(){
    var dummyrowData = this.rowData.map(ele => {
      console.log("ele",ele);
      if(ele.id == this.employeeId){
        ele.InTime = this.employeeInTime != '' ? this.employeeInTime : ele.InTime;
        ele.OutTime = this.employeeOuttime != '' ? this.employeeOuttime : ele.OutTime;
        ele.timeDiff = Math.floor(Number(ele.OutTime - ele.InTime));
      }
      return ele;
    });
    console.log("dummyrowData",dummyrowData);
    this.rowData = dummyrowData;
    this.employeeId = '';
    this.employeeInTime = '';
    this.employeeOuttime = '';
    this.enableUpdateBtn();
  }

  enableUpdateBtn(){
    if(this.employeeId != '' && (this.employeeInTime != '' || this.employeeOuttime != '')){
      this.updateBtnFlag = true;
    }
    else{
      this.updateBtnFlag = false;
    }
  }
}
