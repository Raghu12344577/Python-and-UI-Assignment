from django.shortcuts import render
from productAllocation.models import demandOrder,supply,sourcingRule
from productAllocation.serializers import demandOrderSerializer,supplySerializer,sourcingRuleSerializer
from django.core.files.base import ContentFile
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from django.core import serializers
from rest_framework.decorators import api_view,action
from rest_framework.response import Response
from io import StringIO
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
import pandas as pd
import sqlite3 as db


@api_view(['GET'])
def getDemandOrder(request):
	demandOrderData = demandOrder.objects.all()
	demandOrderData_serializer = demandOrderSerializer(demandOrderData,many=True)
	return JsonResponse(demandOrderData_serializer.data,safe=False)

@api_view(['GET'])
def getSupply(request):
	supplyData = supply.objects.all()
	supplyData_serializer = supplySerializer(supplyData,many=True)
	return JsonResponse(supplyData_serializer.data,safe=False)

@api_view(['GET'])
def getSourcingRule(request):
	sourcingRuleData = sourcingRule.objects.all()
	sourcingRuleData_serializer = sourcingRuleSerializer(sourcingRuleData,many=True)
	return JsonResponse(sourcingRuleData_serializer.data,safe=False)

@api_view(['GET'])
def getOutputData(request):
    dbconnection = db.connect('E:\Django\empHierarchy\db.sqlite3')
    Cursor = dbconnection.cursor()

    df_outputData = pd.read_sql_query("SELECT * from productAllocation_Output", dbconnection)
    outputData = df_outputData.to_dict('records')
    return Response(outputData)