from django.db import models

# Create your models here.
class demandOrder(models.Model):
    customer = models.CharField(max_length=225,primary_key=True)
    product = models.CharField(max_length=225)
    date = models.CharField(max_length=225)
    quantity = models.IntegerField()

class supply(models.Model):
    site = models.IntegerField(primary_key=True)
    product = models.CharField(max_length=225)
    date = models.CharField(max_length=225)
    quantity = models.IntegerField()

class sourcingRule(models.Model):
    site = models.IntegerField(primary_key=True)
    customer = models.CharField(max_length=225)
    product = models.CharField(max_length=225)