from django.db.models import fields
from django.db.models.base import Model
from rest_framework import serializers
from productAllocation.models import demandOrder,supply,sourcingRule


class demandOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model=demandOrder
        fields=('customer','product','date','quantity')

class supplySerializer(serializers.ModelSerializer):
    class Meta:
        model=supply
        fields=('site','product','date','quantity')

class sourcingRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model=sourcingRule
        fields=('site','customer','product')