from django.urls import path
from . import views

urlpatterns = [
    path('DemandOrderlist/',views.getDemandOrder),
    path('Supplylist/',views.getSupply),
    path('Rulelist/',views.getSourcingRule),
    path('Outputlist/',views.getOutputData),
]