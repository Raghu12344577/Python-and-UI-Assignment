from django.db import models

# Create your models here.

class employeeList(models.Model):
    id = models.IntegerField(primary_key=True)
    orgHierarchy = models.CharField(max_length=225)
    name = models.CharField(max_length=225)
    InTime = models.CharField(max_length=225)
    OutTime = models.CharField(max_length=225)