import csv
from sqlite3.dbapi2 import Cursor
from django.core.files.base import ContentFile
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from django.core import serializers
from rest_framework.decorators import api_view,action
from rest_framework.response import Response
from io import StringIO
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser

from employeeList.models import employeeList
from employeeList.serializers import EmployeeListSerializer


from productAllocation.models import demandOrder,supply,sourcingRule
from productAllocation.serializers import demandOrderSerializer,supplySerializer,sourcingRuleSerializer

import pandas as pd
import sqlite3 as db
from PIL import Image
from pytesseract import pytesseract

fs = FileSystemStorage(location = 'tmp/')

# Create your views here.
def EmpDefault(request):
    return HttpResponse('List of Employees in Django')

@api_view(['GET'])
def employeeListApi(request):
	employeeListData = employeeList.objects.all()
	employeeListData_serializer = EmployeeListSerializer(employeeListData,many=True)
	return JsonResponse(employeeListData_serializer.data,safe=False)

@api_view(['POST'])
def productFilesUpload(request):
	dbconnection = db.connect('E:\Django\empHierarchy\db.sqlite3')
	Cursor = dbconnection.cursor()

	file = request.FILES.get('file')
	content = file.read()

	csvin = csv.DictReader(StringIO(content.decode('utf-8')))
	csvin.fieldnames = [name.lower() for name in csvin.fieldnames]
	fileName = request.data['file'].name
	file_content = ContentFile(content)
	file_name = fs.save(fileName,file_content)
	fs.path(file_name)

	df = pd.read_csv('tmp' + '/' + file_name)

	if(fileName == 'demand_order.csv'):
		fileColumn = 4
		if len(csvin.fieldnames) == fileColumn:
			if(set(csvin.fieldnames) == set(['customer','product','date','quantity'])):
				output = 'Demand order file is uploaded successfully'
				df.to_sql(name='productAllocation_demandorder',con=dbconnection,index=False,if_exists="replace")
			else:
				output = 'demand order file columns are not given format properly'	
		else:
			output = 'demand order file column is not matching'	
	elif(fileName == 'sourcing_rule.csv'):
		fileColumn = 3
		if len(csvin.fieldnames) == fileColumn:
			if(set(csvin.fieldnames) == set(['site','customer','product'])):
				output = 'sourcing rule file is uploaded successfully'
				df.to_sql(name='productAllocation_sourcingrule',con=dbconnection,index=False,if_exists="replace")
			else:
				output = 'sourcing rule file columns are not given format properly'
		else:
			output = 'sourcing rule file column is not matching'	
	elif(fileName == 'supply.csv'):
		fileColumn = 4
		if len(csvin.fieldnames) == fileColumn:
			if(set(csvin.fieldnames) == set(['site','product','date','quantity'])):
				output = 'supply file is uploaded successfully'
				df.to_sql(name='productAllocation_supply',con=dbconnection,index=False,if_exists="replace")
			else:
				output = 'supply file columns are not given format properly'
		else:
			output = 'supply file column is not matching'	
	else:
		output = 'Wrong file has been uploaded'
	fs.delete(fileName)

	return Response(output)

@api_view(['POST'])
def extractTextFromImage(request):
	image = request.FILES.get('file')
	Imgcontent = image.read()

	imageName = request.data['file'].name

	image_content = ContentFile(Imgcontent)
	image_name = fs.save(imageName,image_content)
	fs.path(image_name)

	path_to_tesseract = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
	image_path = 'tmp' + '/' + image_name
	imgObject = Image.open(image_path)
	pytesseract.tesseract_cmd = path_to_tesseract
	text = pytesseract.image_to_string(imgObject)
	print(text)
	fs.delete(image_name)
	return Response(text)

@api_view(['GET'])
def supplyManagementAllocationProcess(request):
	dbconnection = db.connect('E:\Django\empHierarchy\db.sqlite3')
	Cursor = dbconnection.cursor()

	df_demand_order = pd.read_sql_query("SELECT * from productAllocation_demandorder", dbconnection)
	df_demand_order['date'] = pd.to_datetime(df_demand_order['date']).dt.normalize()
	df_demand_order['date'] = df_demand_order['date'].dt.date
	
	df_supply = pd.read_sql_query("SELECT * from productAllocation_supply", dbconnection)
	df_supply['date'] = pd.to_datetime(df_supply.date)
	df_supply['date'] = df_supply['date'].dt.strftime('%d/%m/%Y')
	df_supply['date'] = pd.to_datetime(df_supply['date']).dt.normalize()
	df_supply['date'] = df_supply['date'].dt.date
	
	supplyUniqueDateCol = df_supply['date'].unique().tolist()
	supplyOtherCol = ['site', 'customer', 'product']
	supplyColumnsToNew = supplyOtherCol + supplyUniqueDateCol
	
	df_supplyFulfill = pd.DataFrame(columns = supplyColumnsToNew)
	for index, df_demand_row in df_demand_order.iterrows():
		for index, df_supply_row in df_supply.iterrows():
			if(df_demand_row['product'] == df_supply_row['product'] and (df_demand_row['quantity'] > 0 and df_supply_row['quantity'] > 0)):
				if(df_demand_row['date'] == df_supply_row['date']):
					if(df_demand_row['quantity'] == df_supply_row['quantity']):
						df_supplyFulfill = df_supplyFulfill.append({'site' : df_supply_row['site'] , 'customer' : df_demand_row['customer'], 'product' : df_demand_row['product'],df_supply_row['date'] : df_supply_row['quantity']},ignore_index = True)
					elif(df_demand_row['quantity'] > df_supply_row['quantity']):
						df_supplyFulfill = df_supplyFulfill.append({'site' : df_supply_row['site'] , 'customer' : df_demand_row['customer'], 'product' : df_demand_row['product'],df_supply_row['date'] : df_supply_row['quantity']},ignore_index = True)
					elif(df_demand_row['quantity'] < df_supply_row['quantity']):
						df_supplyFulfill = df_supplyFulfill.append({'site' : df_supply_row['site'] , 'customer' : df_demand_row['customer'], 'product' : df_demand_row['product'],df_supply_row['date'] : df_supply_row['quantity']},ignore_index = True)
    
	df_supplyFulfill = df_supplyFulfill.drop_duplicates(subset=['site','customer','product']).reset_index(drop=True)
	df_supplyFulfill = df_supplyFulfill.fillna(0)
	df_supplyFulfill.to_sql(name='productAllocation_Output',con=dbconnection,index=False,if_exists="replace")
	df_supplyFulfill.to_csv("E:\Angular\data sample\demand_supply_Allocation_output.csv", index=False)
	return Response("E:\Angular\data sample\demand_supply_Allocation_output.csv")