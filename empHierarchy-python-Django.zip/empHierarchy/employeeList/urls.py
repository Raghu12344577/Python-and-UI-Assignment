from django.urls import path
from . import views

urlpatterns = [
    path('upload/',views.productFilesUpload),
    path('employeeList/',views.employeeListApi),
    path('extractTextFromImage/',views.extractTextFromImage),
    path('supplyProcessing/',views.supplyManagementAllocationProcess),
]
