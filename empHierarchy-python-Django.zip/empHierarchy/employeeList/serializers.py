from django.db.models import fields
from django.db.models.base import Model
from rest_framework import serializers
from employeeList.models import employeeList


class EmployeeListSerializer(serializers.ModelSerializer):
    class Meta:
        model=employeeList
        fields=('id','orgHierarchy','name','InTime','OutTime')